# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'b9f2915045fb276615842ee33cbaf43a7b973afa10a78799ac9b6f9ba8e420d7ef5ee9e82ad20cef114ed877e71b5ea5a200b5685fd0f6eb54661e6fcf051081'
